<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>captcha</title>
</head>
<body>
    <img src="captchacreate.php" alt="captcha image">
</body>
</html>


<?php


?>
