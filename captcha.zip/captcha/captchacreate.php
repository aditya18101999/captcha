<?php
$height=400;
$width=400;
$image=imagecreate($width,$height);
$black = imagecolorallocate($image,0,0,0);
$white=imagecolorallocate($image,255,255,255);
$x=25;
$y=300;

$font= dirname(__FILE__) . '/font/good times rg.ttf';
$text="Noobieasdadasdasd";
$textlength=strlen($text);
$textarray = str_split($text);

for($i=0;$i<$textlength;$i++){
    $angle=rand(-30,30);    
    imagettftext($image,50,$angle,$x,$y,$white,$font,$textarray[$i]);
    $x+=50;
}

imagepng($image);
header('Content-type: image/png');
?>
